
import { useEffect } from 'react';

// [h, s, l]
const colorStops = [
    // Night
    { hour: 0,  bg: [240, 5, 8],   foreground: [0, 0, 98],   mutedForeground: [200, 10, 75] },
    { hour: 5,  bg: [240, 10, 15], foreground: [0, 0, 98],   mutedForeground: [200, 10, 75] },
    // Day
    { hour: 8,  bg: [210, 50, 95], foreground: [210, 20, 20], mutedForeground: [210, 10, 50] },
    { hour: 11, bg: [30, 100, 96], foreground: [20, 20, 20],  mutedForeground: [20, 10, 50] },
    { hour: 17, bg: [10, 100, 96], foreground: [10, 20, 20],  mutedForeground: [10, 10, 50] },
    { hour: 19, bg: [35, 100, 92], foreground: [25, 20, 20],  mutedForeground: [25, 10, 50] },
    // Night
    { hour: 22, bg: [240, 10, 15], foreground: [0, 0, 98],   mutedForeground: [200, 10, 75] },
    { hour: 24, bg: [240, 5, 8],   foreground: [0, 0, 98],   mutedForeground: [200, 10, 75] },
];

const interpolateHsl = (hsl1: number[], hsl2: number[], factor: number) => {
    let h1 = hsl1[0], h2 = hsl2[0];
    if (Math.abs(h2 - h1) > 180) {
        if (h2 > h1) h1 += 360;
        else h2 += 360;
    }
    const h = (h1 + (h2 - h1) * factor) % 360;
    const s = hsl1[1] + (hsl2[1] - hsl1[1]) * factor;
    const l = hsl1[2] + (hsl2[2] - hsl1[2]) * factor;
    return [Math.round(h), Math.round(s), Math.round(l)];
};

export const useTimeBasedTheme = () => {
  useEffect(() => {
    document.body.classList.add('sand-texture');

    const updateTheme = () => {
      const now = new Date();
      const currentHour = now.getHours() + now.getMinutes() / 60;

      let startStop = colorStops[0];
      let endStop = colorStops[1];

      for (let i = 0; i < colorStops.length - 1; i++) {
        if (currentHour >= colorStops[i].hour && currentHour < colorStops[i + 1].hour) {
          startStop = colorStops[i];
          endStop = colorStops[i + 1];
          break;
        }
      }

      const timeInSegment = currentHour - startStop.hour;
      const segmentDuration = endStop.hour - startStop.hour;
      const factor = segmentDuration === 0 ? 0 : timeInSegment / segmentDuration;

      const [bgH, bgS, bgL] = interpolateHsl(startStop.bg, endStop.bg, factor);
      const [fgH, fgS, fgL] = interpolateHsl(startStop.foreground, endStop.foreground, factor);
      const [mfgH, mfgS, mfgL] = interpolateHsl(startStop.mutedForeground, endStop.mutedForeground, factor);
      
      const root = document.documentElement;
      const foregroundColor = `${fgH} ${fgS}% ${fgL}%`;

      root.style.setProperty('--background', `${bgH} ${bgS}% ${bgL}%`);
      root.style.setProperty('--card', `${bgH} ${bgS}% ${Math.min(100, bgL + 3)}%`);
      
      // Set all key foreground colors for consistency
      root.style.setProperty('--foreground', foregroundColor);
      root.style.setProperty('--card-foreground', foregroundColor);
      root.style.setProperty('--popover-foreground', foregroundColor);
      root.style.setProperty('--secondary-foreground', foregroundColor);
      root.style.setProperty('--accent-foreground', foregroundColor);

      // Set the dynamic muted foreground for less important text
      root.style.setProperty('--muted-foreground', `${mfgH} ${mfgS}% ${mfgL}%`);
    };

    updateTheme();
    const intervalId = setInterval(updateTheme, 60000);

    return () => {
        clearInterval(intervalId);
        document.body.classList.remove('sand-texture');
    };
  }, []);
};
