
export interface MoodEntry {
  id: string;
  date: string;
  mood: number;
  notes?: string;
  energy: number;
  stress: number;
}

export interface JournalEntry {
  id: string;
  date: string;
  title: string;
  content: string;
  tags: string[];
}

export interface Goal {
  id: string;
  title: string;
  description: string;
  progress: number;
  target: number;
  category: string;
}
