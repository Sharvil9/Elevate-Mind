
import React, { useState } from 'react';
import { MoodEntry, JournalEntry, Goal } from '@/types';
import { Header } from '@/components/dashboard/Header';
import { QuickActions } from '@/components/dashboard/QuickActions';
import { MainDashboardTabs } from '@/components/dashboard/MainDashboardTabs';
import { FooterDisclaimer } from '@/components/dashboard/FooterDisclaimer';

const Dashboard = () => {
  const [currentMood, setCurrentMood] = useState<number>(5);
  const [currentEnergy, setCurrentEnergy] = useState<number>(5);
  const [currentStress, setCurrentStress] = useState<number>(5);
  const [moodNotes, setMoodNotes] = useState<string>('');
  const [journalTitle, setJournalTitle] = useState<string>('');
  const [journalContent, setJournalContent] = useState<string>('');
  
  // Sample data - in production, this would come from Firestore
  const [moodEntries] = useState<MoodEntry[]>([
    { id: '1', date: '2024-06-10', mood: 7, energy: 6, stress: 4 },
    { id: '2', date: '2024-06-11', mood: 6, energy: 5, stress: 6 },
    { id: '3', date: '2024-06-12', mood: 8, energy: 7, stress: 3 },
    { id: '4', date: '2024-06-13', mood: 5, energy: 4, stress: 7 },
    { id: '5', date: '2024-06-14', mood: 7, energy: 6, stress: 4 },
  ]);

  const [journalEntries] = useState<JournalEntry[]>([
    {
      id: '1',
      date: '2024-06-14',
      title: 'Morning Reflections',
      content: 'Started the day with meditation. Feeling grateful for the small moments...',
      tags: ['gratitude', 'meditation']
    },
    {
      id: '2',
      date: '2024-06-13',
      title: 'Challenging Day',
      content: 'Work was stressful today, but I managed to take breaks and practice breathing exercises...',
      tags: ['stress', 'breathing', 'work']
    }
  ]);

  const [goals] = useState<Goal[]>([
    { id: '1', title: 'Daily Meditation', description: '10 minutes daily', progress: 5, target: 7, category: 'mindfulness' },
    { id: '2', title: 'Exercise Routine', description: '3 times per week', progress: 2, target: 3, category: 'physical' },
    { id: '3', title: 'Gratitude Journal', description: '3 things daily', progress: 4, target: 7, category: 'emotional' }
  ]);

  const [aiInsights] = useState([
    "Your mood has been consistently improving over the past week. Consider what positive changes you've made recently.",
    "You tend to have higher energy levels on days when your stress is lower. Try incorporating more stress-reduction techniques.",
    "Your journal entries show a pattern of growth through challenges. You're developing strong resilience skills."
  ]);

  const handleMoodSubmit = () => {
    // In production, save to Firestore
    console.log('Saving mood entry:', { mood: currentMood, energy: currentEnergy, stress: currentStress, notes: moodNotes });
    setMoodNotes('');
  };

  const handleJournalSubmit = () => {
    // In production, save to Firestore
    console.log('Saving journal entry:', { title: journalTitle, content: journalContent });
    setJournalTitle('');
    setJournalContent('');
  };

  return (
    <div className="min-h-screen p-4">
      <div className="max-w-7xl mx-auto space-y-6">
        <Header />

        <QuickActions
          currentMood={currentMood}
          setCurrentMood={setCurrentMood}
          currentEnergy={currentEnergy}
          setCurrentEnergy={setCurrentEnergy}
          currentStress={currentStress}
          setCurrentStress={setCurrentStress}
          moodNotes={moodNotes}
          setMoodNotes={setMoodNotes}
          handleMoodSubmit={handleMoodSubmit}
          journalTitle={journalTitle}
          setJournalTitle={setJournalTitle}
          journalContent={journalContent}
          setJournalContent={setJournalContent}
          handleJournalSubmit={handleJournalSubmit}
        />

        <MainDashboardTabs
          moodEntries={moodEntries}
          aiInsights={aiInsights}
          goals={goals}
          journalEntries={journalEntries}
        />

        <FooterDisclaimer />
      </div>
    </div>
  );
};

export default Dashboard;
