
import React from 'react';
import { HeroSection } from '@/components/sections/HeroSection';
import { FeaturesSection } from '@/components/sections/FeaturesSection';
import { DesignSection } from '@/components/sections/DesignSection';
import { PersonaSection } from '@/components/sections/PersonaSection';
import { CursorTracker } from '@/components/ui/cursor-tracker';
import { Web3Particles } from '@/components/effects/web3-particles';
import { FloatingParticles } from '@/components/effects/floating-particles';

const Index = () => {
  return (
    <div className="min-h-screen">
      <CursorTracker />
      <Web3Particles />
      <FloatingParticles />
      <HeroSection />
      <FeaturesSection />
      <DesignSection />
      <PersonaSection />
      
      {/* Footer */}
      <footer className="bg-gray-50 border-t border-gray-200 py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h3 className="font-cormorant text-3xl font-medium text-meditation-primary mb-4">
            ElevateMind
          </h3>
          <p className="text-gray-600 text-lg">
            The result is a calm, intuitive experience that supports daily mindfulness.
          </p>
        </div>
      </footer>
    </div>
  );
};

export default Index;
