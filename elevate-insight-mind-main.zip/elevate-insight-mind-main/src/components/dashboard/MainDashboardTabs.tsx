
import React from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { OverviewTab } from './tabs/OverviewTab';
import { AIInsightsTab } from './tabs/AIInsightsTab';
import { GoalsTab } from './tabs/GoalsTab';
import { JournalTab } from './tabs/JournalTab';
import { MoodEntry, JournalEntry, Goal } from '@/types';

interface MainDashboardTabsProps {
  moodEntries: MoodEntry[];
  aiInsights: string[];
  goals: Goal[];
  journalEntries: JournalEntry[];
}

export const MainDashboardTabs: React.FC<MainDashboardTabsProps> = ({
  moodEntries,
  aiInsights,
  goals,
  journalEntries,
}) => {
  return (
    <Tabs defaultValue="overview" className="w-full">
      <TabsList className="grid w-full grid-cols-4">
        <TabsTrigger value="overview">Overview</TabsTrigger>
        <TabsTrigger value="insights">AI Insights</TabsTrigger>
        <TabsTrigger value="goals">Goals</TabsTrigger>
        <TabsTrigger value="journal">Journal</TabsTrigger>
      </TabsList>

      <TabsContent value="overview" className="mt-6 space-y-6">
        <OverviewTab moodEntries={moodEntries} />
      </TabsContent>
      <TabsContent value="insights" className="mt-6 space-y-6">
        <AIInsightsTab aiInsights={aiInsights} />
      </TabsContent>
      <TabsContent value="goals" className="mt-6 space-y-6">
        <GoalsTab goals={goals} />
      </TabsContent>
      <TabsContent value="journal" className="mt-6 space-y-6">
        <JournalTab journalEntries={journalEntries} />
      </TabsContent>
    </Tabs>
  );
};
