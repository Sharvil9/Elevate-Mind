
import React from 'react';
import { QuickMoodCheck } from './QuickMoodCheck';
import { JournalEntryForm } from './JournalEntryForm';
import { TodaysPrompt } from './TodaysPrompt';

interface QuickActionsProps {
  currentMood: number;
  setCurrentMood: (value: number) => void;
  currentEnergy: number;
  setCurrentEnergy: (value: number) => void;
  currentStress: number;
  setCurrentStress: (value: number) => void;
  moodNotes: string;
  setMoodNotes: (value: string) => void;
  handleMoodSubmit: () => void;
  journalTitle: string;
  setJournalTitle: (value: string) => void;
  journalContent: string;
  setJournalContent: (value: string) => void;
  handleJournalSubmit: () => void;
}

export const QuickActions: React.FC<QuickActionsProps> = (props) => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
      <QuickMoodCheck
        currentMood={props.currentMood}
        setCurrentMood={props.setCurrentMood}
        currentEnergy={props.currentEnergy}
        setCurrentEnergy={props.setCurrentEnergy}
        currentStress={props.currentStress}
        setCurrentStress={props.setCurrentStress}
        moodNotes={props.moodNotes}
        setMoodNotes={props.setMoodNotes}
        handleMoodSubmit={props.handleMoodSubmit}
      />
      <JournalEntryForm
        journalTitle={props.journalTitle}
        setJournalTitle={props.setJournalTitle}
        journalContent={props.journalContent}
        setJournalContent={props.setJournalContent}
        handleJournalSubmit={props.handleJournalSubmit}
      />
      <TodaysPrompt />
    </div>
  );
};
