
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { ChevronRight, Lightbulb } from 'lucide-react';

const journalPrompts = [
    "What are three things you're grateful for today?",
    "Describe a moment today when you felt truly present.",
    "What's one small step you can take tomorrow to improve your well-being?",
    "How did you show kindness to yourself or others today?",
    "What emotions did you experience today, and what triggered them?"
];

export const TodaysPrompt = () => {
  const prompt = journalPrompts[Math.floor(Math.random() * journalPrompts.length)];

  return (
    <Card className="bg-card/20 backdrop-blur-md border border-card-foreground/10 shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-[1.02]">
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center gap-2 text-foreground">
          <Lightbulb className="h-5 w-5" />
          Today's Prompt
        </CardTitle>
      </CardHeader>
      <CardContent>
        <p className="text-sm text-foreground/80 mb-4 h-24">
          {prompt}
        </p>
        <Button variant="outline" className="w-full">
          <ChevronRight className="h-4 w-4 mr-2" />
          Reflect on This
        </Button>
      </CardContent>
    </Card>
  );
};
