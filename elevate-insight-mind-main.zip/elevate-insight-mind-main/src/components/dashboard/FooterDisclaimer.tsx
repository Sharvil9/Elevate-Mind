
import React from 'react';
import { Card, CardContent } from '@/components/ui/card';

export const FooterDisclaimer = () => {
  return (
    <Card className="bg-yellow-50 border-yellow-200">
      <CardContent className="pt-6">
        <p className="text-sm text-gray-600 text-center">
          <strong>Important Disclaimer:</strong> ElevateMind is a personal well-being tracker and resource guide. 
          It is not intended to provide medical advice, diagnosis, or treatment. It is a tool for self-reflection 
          and habit formation. If you are experiencing a mental health crisis, or require professional support, 
          please seek help from a qualified healthcare provider immediately.
        </p>
      </CardContent>
    </Card>
  );
};
