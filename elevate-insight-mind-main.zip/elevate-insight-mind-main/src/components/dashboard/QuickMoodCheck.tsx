
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Slider } from '@/components/ui/slider';
import { Heart, Plus, Smile, Meh, Frown } from 'lucide-react';

interface QuickMoodCheckProps {
  currentMood: number;
  setCurrentMood: (value: number) => void;
  currentEnergy: number;
  setCurrentEnergy: (value: number) => void;
  currentStress: number;
  setCurrentStress: (value: number) => void;
  moodNotes: string;
  setMoodNotes: (value: string) => void;
  handleMoodSubmit: () => void;
}

const getMoodIcon = (mood: number) => {
  if (mood >= 7) return <Smile className="h-5 w-5 text-green-500" />;
  if (mood >= 4) return <Meh className="h-5 w-5 text-yellow-500" />;
  return <Frown className="h-5 w-5 text-red-500" />;
};

export const QuickMoodCheck: React.FC<QuickMoodCheckProps> = ({
  currentMood,
  setCurrentMood,
  currentEnergy,
  setCurrentEnergy,
  currentStress,
  setCurrentStress,
  moodNotes,
  setMoodNotes,
  handleMoodSubmit,
}) => {
  return (
    <Card className="bg-card/20 backdrop-blur-md border border-card-foreground/10 shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-[1.02]">
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center gap-2 text-foreground">
          <Heart className="h-5 w-5" />
          Quick Mood Check
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-6">
          <div>
            <div className="flex justify-between items-center mb-2">
              <Label htmlFor="mood-slider" className="text-sm font-medium">How are you feeling?</Label>
              <span className="text-sm font-bold text-foreground/80 w-16 text-center flex items-center justify-center gap-1">
                {getMoodIcon(currentMood)} {currentMood}
              </span>
            </div>
            <Slider
                id="mood-slider"
                min={1}
                max={10}
                step={1}
                value={[currentMood]}
                onValueChange={(value) => setCurrentMood(value[0])}
                className="mt-1"
            />
          </div>
          <div>
            <div className="flex justify-between items-center mb-2">
              <Label htmlFor="energy-slider" className="text-sm font-medium">Energy Level</Label>
              <span className="text-sm font-bold text-foreground/80 w-16 text-center">{currentEnergy}</span>
            </div>
            <Slider
                id="energy-slider"
                min={1}
                max={10}
                step={1}
                value={[currentEnergy]}
                onValueChange={(value) => setCurrentEnergy(value[0])}
                className="mt-1"
            />
          </div>
          <div>
            <div className="flex justify-between items-center mb-2">
              <Label htmlFor="stress-slider" className="text-sm font-medium">Stress Level</Label>
              <span className="text-sm font-bold text-foreground/80 w-16 text-center">{currentStress}</span>
            </div>
            <Slider
                id="stress-slider"
                min={1}
                max={10}
                step={1}
                value={[currentStress]}
                onValueChange={(value) => setCurrentStress(value[0])}
                className="mt-1"
            />
          </div>
          <Textarea
            placeholder="Any notes about your mood today?"
            value={moodNotes}
            onChange={(e) => setMoodNotes(e.target.value)}
            className="mt-2 bg-transparent placeholder:text-foreground/60"
          />
          <Button onClick={handleMoodSubmit} className="w-full">
            <Plus className="h-4 w-4 mr-2" />
            Log Mood
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};
