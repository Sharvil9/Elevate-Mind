
import React from 'react';
import { Heart, Moon, Sunrise } from 'lucide-react';

const getTimeGreeting = () => {
  const hour = new Date().getHours();
  if (hour < 12) return { text: "Good morning", icon: <Sunrise className="h-5 w-5" /> };
  if (hour < 18) return { text: "Good afternoon", icon: <Heart className="h-5 w-5" /> };
  return { text: "Good evening", icon: <Moon className="h-5 w-5" /> };
};

export const Header = () => {
  const greeting = getTimeGreeting();

  return (
    <div className="text-center py-8">
      <div className="flex items-center justify-center gap-2 mb-4">
        {greeting.icon}
        <h1 className="text-3xl font-bold">{greeting.text}</h1>
      </div>
      <p className="text-lg text-foreground/80">Welcome to your personal wellness sanctuary</p>
    </div>
  );
};
