
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { BookOpen, Plus } from 'lucide-react';

interface JournalEntryFormProps {
  journalTitle: string;
  setJournalTitle: (value: string) => void;
  journalContent: string;
  setJournalContent: (value: string) => void;
  handleJournalSubmit: () => void;
}

export const JournalEntryForm: React.FC<JournalEntryFormProps> = ({
  journalTitle,
  setJournalTitle,
  journalContent,
  setJournalContent,
  handleJournalSubmit,
}) => {
  return (
    <Card className="bg-card/20 backdrop-blur-md border border-card-foreground/10 shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-[1.02]">
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center gap-2 text-foreground">
          <BookOpen className="h-5 w-5" />
          Journal Entry
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <Input
            placeholder="Entry title..."
            value={journalTitle}
            onChange={(e) => setJournalTitle(e.target.value)}
            className="bg-transparent placeholder:text-foreground/60"
          />
          <Textarea
            placeholder="What's on your mind today?"
            value={journalContent}
            onChange={(e) => setJournalContent(e.target.value)}
            rows={8}
            className="bg-transparent placeholder:text-foreground/60"
          />
          <Button onClick={handleJournalSubmit} className="w-full">
            <Plus className="h-4 w-4 mr-2" />
            Save Entry
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};
