
import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { Calendar, Smile, Meh, Frown, TrendingUp } from 'lucide-react';
import { MoodEntry } from '@/types';

interface OverviewTabProps {
  moodEntries: MoodEntry[];
}

const getMoodIcon = (mood: number) => {
  if (mood >= 7) return <Smile className="h-5 w-5 text-green-500" />;
  if (mood >= 4) return <Meh className="h-5 w-5 text-yellow-500" />;
  return <Frown className="h-5 w-5 text-red-500" />;
};

export const OverviewTab: React.FC<OverviewTabProps> = ({ moodEntries }) => {
  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      {/* Mood Trends */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <TrendingUp className="h-5 w-5" />
            Mood Trends
          </CardTitle>
          <CardDescription>Your emotional journey over the past week</CardDescription>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={moodEntries}>
              <defs>
                <filter id="shadow" x="-20%" y="-20%" width="140%" height="140%">
                  <feDropShadow dx="2" dy="2" stdDeviation="3" floodColor="rgba(0,0,0,0.1)" />
                </filter>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
              <XAxis dataKey="date" stroke="hsl(var(--muted-foreground))" fontSize={12} />
              <YAxis domain={[1, 10]} stroke="hsl(var(--muted-foreground))" fontSize={12} />
              <Tooltip
                contentStyle={{
                  background: "hsl(var(--background))",
                  border: "1px solid hsl(var(--border))",
                  borderRadius: "var(--radius)"
                }}
              />
              <Line type="monotone" dataKey="mood" name="Mood" stroke="#3b82f6" strokeWidth={3} style={{ filter: 'url(#shadow)' }} dot={false} />
              <Line type="monotone" dataKey="energy" name="Energy" stroke="#10b981" strokeWidth={2} style={{ filter: 'url(#shadow)' }} dot={false} />
              <Line type="monotone" dataKey="stress" name="Stress" stroke="#ef4444" strokeWidth={2} style={{ filter: 'url(#shadow)' }} dot={false} />
            </LineChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      {/* Recent Entries */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Calendar className="h-5 w-5" />
            Recent Entries
          </CardTitle>
          <CardDescription>Your latest mood and journal entries</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {moodEntries.slice(-3).reverse().map((entry) => (
              <div key={entry.id} className="flex items-center justify-between p-3 bg-muted/30 rounded-lg">
                <div className="flex items-center gap-3">
                  {getMoodIcon(entry.mood)}
                  <div>
                    <p className="text-sm font-medium text-foreground">{entry.date}</p>
                    <p className="text-xs text-muted-foreground">Mood: {entry.mood}/10</p>
                  </div>
                </div>
                <Badge variant="secondary">{entry.mood >= 7 ? 'Great' : entry.mood >= 4 ? 'Okay' : 'Tough'}</Badge>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};
