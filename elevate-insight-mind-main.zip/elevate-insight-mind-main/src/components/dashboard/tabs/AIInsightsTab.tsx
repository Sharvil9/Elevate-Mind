
import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Brain } from 'lucide-react';

interface AIInsightsTabProps {
  aiInsights: string[];
}

export const AIInsightsTab: React.FC<AIInsightsTabProps> = ({ aiInsights }) => {
  return (
    <Card className="animate-float-gentle">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Brain className="h-5 w-5" />
          AI-Powered Insights
        </CardTitle>
        <CardDescription>Personalized observations about your well-being patterns</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {aiInsights.map((insight, index) => (
            <div key={index} className="p-4 bg-primary/10 rounded-lg border-l-4 border-primary">
              <p className="text-foreground/80">{insight}</p>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
};
