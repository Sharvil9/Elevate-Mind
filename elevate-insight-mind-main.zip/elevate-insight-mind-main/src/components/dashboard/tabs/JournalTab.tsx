
import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { JournalEntry } from '@/types';

interface JournalTabProps {
  journalEntries: JournalEntry[];
}

export const JournalTab: React.FC<JournalTabProps> = ({ journalEntries }) => {
  return (
    <div className="space-y-4">
      {journalEntries.map((entry) => (
        <Card key={entry.id}>
          <CardHeader>
            <CardTitle>{entry.title}</CardTitle>
            <CardDescription>{entry.date}</CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-gray-700 mb-3">{entry.content}</p>
            <div className="flex gap-2">
              {entry.tags.map((tag) => (
                <Badge key={tag} variant="secondary">#{tag}</Badge>
              ))}
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
};
