
import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { AnimatedProgress } from '@/components/ui/animated-progress';
import { Target } from 'lucide-react';
import { Goal } from '@/types';

interface GoalsTabProps {
  goals: Goal[];
}

export const GoalsTab: React.FC<GoalsTabProps> = ({ goals }) => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {goals.map((goal) => (
        <Card key={goal.id}>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Target className="h-5 w-5" />
              {goal.title}
            </CardTitle>
            <CardDescription>{goal.description}</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="flex justify-between text-sm">
                <span>Progress</span>
                <span>{goal.progress}/{goal.target}</span>
              </div>
              <AnimatedProgress value={(goal.progress / goal.target) * 100} className="h-2" />
              <Badge variant="outline" className="capitalize">{goal.category}</Badge>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
};
