
import React, { useEffect, useRef, useState } from 'react';

export const ImmersiveBanner: React.FC = () => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [mousePos, setMousePos] = useState({ x: 0, y: 0 });

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const resizeCanvas = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight * 0.8;
    };

    resizeCanvas();
    window.addEventListener('resize', resizeCanvas);

    let animationId: number;
    let time = 0;

    const animate = () => {
      time += 0.01;
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      // Create dynamic gradient based on mouse position and time
      const gradient = ctx.createRadialGradient(
        mousePos.x, mousePos.y, 0,
        mousePos.x, mousePos.y, Math.max(canvas.width, canvas.height)
      );

      const hue1 = (time * 20) % 360;
      const hue2 = (time * 30 + 120) % 360;
      const hue3 = (time * 40 + 240) % 360;

      gradient.addColorStop(0, `hsla(${hue1}, 80%, 60%, 0.3)`);
      gradient.addColorStop(0.3, `hsla(${hue2}, 70%, 50%, 0.2)`);
      gradient.addColorStop(0.7, `hsla(${hue3}, 90%, 40%, 0.1)`);
      gradient.addColorStop(1, 'hsla(280, 100%, 20%, 0.05)');

      ctx.fillStyle = gradient;
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      // Add floating orbs
      for (let i = 0; i < 5; i++) {
        const x = canvas.width * 0.2 + Math.sin(time + i) * 200;
        const y = canvas.height * 0.3 + Math.cos(time * 1.5 + i) * 100;
        const radius = 20 + Math.sin(time * 2 + i) * 10;

        const orbGradient = ctx.createRadialGradient(x, y, 0, x, y, radius);
        orbGradient.addColorStop(0, `hsla(${(hue1 + i * 60) % 360}, 100%, 80%, 0.8)`);
        orbGradient.addColorStop(1, `hsla(${(hue1 + i * 60) % 360}, 100%, 60%, 0)`);

        ctx.beginPath();
        ctx.arc(x, y, radius, 0, Math.PI * 2);
        ctx.fillStyle = orbGradient;
        ctx.fill();
      }

      // Add neural network lines
      ctx.strokeStyle = `hsla(${hue1}, 100%, 70%, 0.3)`;
      ctx.lineWidth = 2;
      ctx.beginPath();
      for (let i = 0; i < 10; i++) {
        const startX = Math.sin(time + i * 0.5) * canvas.width * 0.3 + canvas.width * 0.5;
        const startY = Math.cos(time + i * 0.3) * canvas.height * 0.2 + canvas.height * 0.4;
        const endX = Math.sin(time + i * 0.7 + 1) * canvas.width * 0.4 + canvas.width * 0.5;
        const endY = Math.cos(time + i * 0.4 + 1) * canvas.height * 0.3 + canvas.height * 0.5;
        
        ctx.moveTo(startX, startY);
        ctx.lineTo(endX, endY);
      }
      ctx.stroke();

      animationId = requestAnimationFrame(animate);
    };

    animate();

    const handleMouseMove = (e: MouseEvent) => {
      const rect = canvas.getBoundingClientRect();
      setMousePos({
        x: e.clientX - rect.left,
        y: e.clientY - rect.top
      });
    };

    canvas.addEventListener('mousemove', handleMouseMove);

    return () => {
      window.removeEventListener('resize', resizeCanvas);
      canvas.removeEventListener('mousemove', handleMouseMove);
      if (animationId) cancelAnimationFrame(animationId);
    };
  }, [mousePos]);

  return (
    <div className="absolute inset-0 overflow-hidden">
      <canvas
        ref={canvasRef}
        className="absolute inset-0 w-full h-full"
        style={{ filter: 'blur(0.5px)' }}
      />
      <div className="absolute inset-0 bg-gradient-to-br from-transparent via-purple-900/10 to-blue-900/20" />
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,rgba(139,92,246,0.1),transparent_70%)]" />
    </div>
  );
};
