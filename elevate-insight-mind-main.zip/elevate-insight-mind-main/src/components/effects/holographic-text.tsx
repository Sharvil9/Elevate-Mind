
import React, { useState, useEffect } from 'react';

interface HolographicTextProps {
  children: React.ReactNode;
  className?: string;
  intensity?: 'subtle' | 'medium' | 'intense';
  animated?: boolean;
}

export const HolographicText: React.FC<HolographicTextProps> = ({
  children,
  className = '',
  intensity = 'medium',
  animated = true
}) => {
  const [mousePos, setMousePos] = useState({ x: 0, y: 0 });
  const [time, setTime] = useState(0);

  useEffect(() => {
    if (!animated) return;

    const interval = setInterval(() => {
      setTime(prev => prev + 0.1);
    }, 50);

    return () => clearInterval(interval);
  }, [animated]);

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    setMousePos({
      x: (e.clientX - rect.left) / rect.width,
      y: (e.clientY - rect.top) / rect.height
    });
  };

  const intensityStyles = {
    subtle: {
      filter: `hue-rotate(${Math.sin(time) * 30}deg) saturate(1.2)`,
      textShadow: `
        0 0 5px rgba(139, 92, 246, 0.5),
        0 0 10px rgba(59, 130, 246, 0.3),
        0 0 15px rgba(139, 92, 246, 0.2)
      `
    },
    medium: {
      filter: `hue-rotate(${Math.sin(time) * 60}deg) saturate(1.5)`,
      textShadow: `
        0 0 5px rgba(139, 92, 246, 0.8),
        0 0 10px rgba(59, 130, 246, 0.6),
        0 0 15px rgba(139, 92, 246, 0.4),
        0 0 20px rgba(99, 102, 241, 0.3)
      `
    },
    intense: {
      filter: `hue-rotate(${Math.sin(time) * 90}deg) saturate(2)`,
      textShadow: `
        0 0 5px rgba(139, 92, 246, 1),
        0 0 10px rgba(59, 130, 246, 0.8),
        0 0 15px rgba(139, 92, 246, 0.6),
        0 0 20px rgba(99, 102, 241, 0.5),
        0 0 35px rgba(139, 92, 246, 0.4)
      `
    }
  };

  return (
    <div
      className={`relative inline-block ${className}`}
      onMouseMove={handleMouseMove}
    >
      {/* Main text */}
      <div
        className="relative z-10 bg-gradient-to-r from-purple-400 via-blue-500 to-purple-600 bg-clip-text text-transparent"
        style={{
          ...intensityStyles[intensity],
          transform: `perspective(1000px) rotateY(${mousePos.x * 2 - 1}deg) rotateX(${mousePos.y * 2 - 1}deg)`
        }}
      >
        {children}
      </div>

      {/* Holographic layers */}
      <div
        className="absolute inset-0 bg-gradient-to-r from-cyan-400 via-purple-500 to-pink-500 bg-clip-text text-transparent opacity-30 blur-sm"
        style={{
          transform: `translate(${Math.sin(time * 0.5) * 2}px, ${Math.cos(time * 0.7) * 1}px)`,
          filter: `hue-rotate(${Math.sin(time * 1.2) * 180}deg)`
        }}
      >
        {children}
      </div>

      <div
        className="absolute inset-0 bg-gradient-to-r from-pink-400 via-purple-500 to-cyan-500 bg-clip-text text-transparent opacity-20 blur-md"
        style={{
          transform: `translate(${Math.sin(time * 0.8) * -1}px, ${Math.cos(time * 0.4) * 2}px)`,
          filter: `hue-rotate(${Math.sin(time * 0.8) * -90}deg)`
        }}
      >
        {children}
      </div>

      {/* Scanning line effect */}
      <div
        className="absolute inset-0 bg-gradient-to-b from-transparent via-white/10 to-transparent opacity-0 hover:opacity-100 transition-opacity duration-500"
        style={{
          transform: `translateY(${Math.sin(time * 2) * 100}%)`,
          height: '20%',
          filter: 'blur(1px)'
        }}
      />
    </div>
  );
};
