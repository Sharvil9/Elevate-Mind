
import React, { useState, useRef } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';

interface GlassmorphismCardProps {
  children: React.ReactNode;
  title?: string;
  description?: string;
  className?: string;
  intensity?: 'low' | 'medium' | 'high';
}

export const GlassmorphismCard: React.FC<GlassmorphismCardProps> = ({
  children,
  title,
  description,
  className = '',
  intensity = 'medium'
}) => {
  const [mousePos, setMousePos] = useState({ x: 0, y: 0 });
  const [isHovered, setIsHovered] = useState(false);
  const cardRef = useRef<HTMLDivElement>(null);

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!cardRef.current) return;
    
    const rect = cardRef.current.getBoundingClientRect();
    const centerX = rect.left + rect.width / 2;
    const centerY = rect.top + rect.height / 2;
    
    setMousePos({
      x: (e.clientX - centerX) / (rect.width / 2),
      y: (e.clientY - centerY) / (rect.height / 2)
    });
  };

  const intensityClasses = {
    low: 'backdrop-blur-sm bg-white/10 border-white/20',
    medium: 'backdrop-blur-md bg-white/15 border-white/30',
    high: 'backdrop-blur-lg bg-white/20 border-white/40'
  };

  const transformStyle = {
    transform: isHovered 
      ? `perspective(1000px) rotateY(${mousePos.x * 5}deg) rotateX(${-mousePos.y * 5}deg) translateZ(20px)` 
      : 'none',
    transition: 'transform 0.3s ease-out'
  };

  const gradientOverlay = {
    background: isHovered
      ? `radial-gradient(circle at ${(mousePos.x + 1) * 50}% ${(mousePos.y + 1) * 50}%, 
         rgba(139, 92, 246, 0.15) 0%, 
         rgba(59, 130, 246, 0.1) 50%, 
         transparent 100%)`
      : 'transparent',
    transition: 'background 0.3s ease-out'
  };

  return (
    <div
      ref={cardRef}
      className={`relative group ${className}`}
      style={transformStyle}
      onMouseMove={handleMouseMove}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      {/* Animated border */}
      <div className="absolute inset-0 rounded-lg bg-gradient-to-r from-purple-500/20 via-blue-500/20 to-purple-500/20 animate-pulse opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
      
      {/* Main card */}
      <Card className={`relative border-0 shadow-2xl ${intensityClasses[intensity]} overflow-hidden transition-all duration-300 hover:shadow-purple-500/20`}>
        <div 
          className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-500"
          style={gradientOverlay}
        />
        
        {/* Floating particles effect */}
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          {[...Array(6)].map((_, i) => (
            <div
              key={i}
              className={`absolute w-1 h-1 bg-blue-400 rounded-full opacity-0 group-hover:opacity-60 transition-all duration-1000`}
              style={{
                left: `${20 + i * 15}%`,
                top: `${30 + (i % 2) * 40}%`,
                transform: isHovered ? `translateY(-${i * 5}px) scale(1.5)` : 'none',
                transitionDelay: `${i * 100}ms`
              }}
            />
          ))}
        </div>

        {(title || description) && (
          <CardHeader className="relative z-10">
            {title && <CardTitle className="text-white/90">{title}</CardTitle>}
            {description && <CardDescription className="text-white/70">{description}</CardDescription>}
          </CardHeader>
        )}
        
        <CardContent className="relative z-10">
          {children}
        </CardContent>
      </Card>
    </div>
  );
};
