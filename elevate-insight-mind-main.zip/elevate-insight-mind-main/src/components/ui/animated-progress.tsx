
import React, { useEffect, useState } from 'react';
import { Progress } from '@/components/ui/progress';
import { cn } from '@/lib/utils';

interface AnimatedProgressProps {
  value: number;
  className?: string;
}

export const AnimatedProgress: React.FC<AnimatedProgressProps> = ({ value, className }) => {
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    // Animate from 0 to value after a short delay
    if (value > 0) {
      const timer = setTimeout(() => setProgress(value), 300);
      return () => clearTimeout(timer);
    }
  }, [value]);

  return <Progress value={progress} className={cn("transition-all duration-1000 ease-out", className)} />;
};
