
import React, { useEffect, useState } from 'react';

interface CursorPosition {
  x: number;
  y: number;
}

export const CursorTracker: React.FC = () => {
  const [cursorPos, setCursorPos] = useState<CursorPosition>({ x: 0, y: 0 });
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      setCursorPos({ x: e.clientX, y: e.clientY });
      setIsVisible(true);
    };

    const handleMouseLeave = () => {
      setIsVisible(false);
    };

    window.addEventListener('mousemove', handleMouseMove);
    document.addEventListener('mouseleave', handleMouseLeave);
    
    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      document.removeEventListener('mouseleave', handleMouseLeave);
    };
  }, []);

  if (!isVisible) return null;

  return (
    <>
      {/* Main pearly glow */}
      <div
        className="fixed pointer-events-none z-50 w-8 h-8 rounded-full transition-all duration-150 ease-out"
        style={{
          left: cursorPos.x - 16,
          top: cursorPos.y - 16,
          background: 'radial-gradient(circle, rgba(255,255,255,0.8) 0%, rgba(180,225,225,0.6) 30%, rgba(74,155,155,0.4) 60%, transparent 100%)',
          boxShadow: '0 0 20px rgba(255,255,255,0.5), 0 0 40px rgba(180,225,225,0.3), 0 0 60px rgba(74,155,155,0.2)',
        }}
      />
      
      {/* Outer glow ring */}
      <div
        className="fixed pointer-events-none z-40 w-16 h-16 rounded-full transition-all duration-300 ease-out opacity-30"
        style={{
          left: cursorPos.x - 32,
          top: cursorPos.y - 32,
          background: 'radial-gradient(circle, transparent 60%, rgba(255,255,255,0.3) 70%, rgba(180,225,225,0.2) 80%, transparent 100%)',
          animation: 'pulse 2s ease-in-out infinite',
        }}
      />
    </>
  );
};
