import React, { useEffect, useState } from 'react';

interface CursorPosition {
  x: number;
  y: number;
}

export const CursorTracker: React.FC = () => {
  const [cursorPos, setCursorPos] = useState<CursorPosition>({ x: 0, y: 0 });
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      setCursorPos({ x: e.clientX, y: e.clientY });
      if (!isVisible) setIsVisible(true);
    };
    
    const handleMouseLeave = () => setIsVisible(false);

    window.addEventListener('mousemove', handleMouseMove);
    document.documentElement.addEventListener('mouseleave', handleMouseLeave);
    
    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      document.documentElement.removeEventListener('mouseleave', handleMouseLeave);
    };
  }, [isVisible]);

  return (
    <>
      {/* Main pearly glow */}
      <div
        className="fixed pointer-events-none z-50 w-8 h-8 rounded-full transition-opacity duration-300"
        style={{
          left: cursorPos.x - 16,
          top: cursorPos.y - 16,
          background: 'radial-gradient(circle, hsla(var(--foreground), 0.1) 0%, hsla(var(--primary), 0.2) 30%, hsla(var(--primary), 0.1) 60%, transparent 80%)',
          boxShadow: '0 0 20px hsla(var(--primary), 0.2), 0 0 40px hsla(var(--primary), 0.1), 0 0 60px hsla(var(--primary), 0.05)',
          opacity: isVisible ? 1 : 0,
        }}
      />
      
      {/* Outer glow ring */}
      <div
        className="fixed pointer-events-none z-40 w-16 h-16 rounded-full transition-opacity duration-300 animate-pulse"
        style={{
          left: cursorPos.x - 32,
          top: cursorPos.y - 32,
          background: 'radial-gradient(circle, transparent 60%, hsla(var(--primary), 0.1) 70%, hsla(var(--primary), 0.05) 80%, transparent 100%)',
          opacity: isVisible ? 0.3 : 0,
        }}
      />
    </>
  );
};

export const IlluminatedButton: React.FC<{
  children: React.ReactNode;
  onClick?: () => void;
  className?: string;
  variant?: 'purple' | 'green';
}> = ({ children, onClick, className = '', variant = 'purple' }) => {
  const [isHovered, setIsHovered] = useState(false);

  const baseClasses = variant === 'purple' 
    ? "relative overflow-hidden bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white font-semibold py-3 px-6 rounded-lg transition-all duration-300 transform hover:scale-105 hover:shadow-2xl hover:shadow-purple-500/30"
    : "relative overflow-hidden bg-gradient-to-r from-green-500 to-emerald-500 hover:from-green-600 hover:to-emerald-600 text-white font-semibold py-3 px-6 rounded-lg transition-all duration-300 transform hover:scale-105 hover:shadow-2xl hover:shadow-green-500/30";

  return (
    <button
      className={`${baseClasses} ${className}`}
      onClick={onClick}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      {isHovered && (
        <>
          <div className="absolute inset-0 bg-gradient-to-r from-white/20 to-transparent animate-pulse" />
          <div className="absolute -inset-1 bg-gradient-to-r from-purple-600 to-blue-600 rounded-lg blur opacity-30 animate-pulse" />
        </>
      )}
      <span className="relative z-10 flex items-center gap-2">
        {children}
      </span>
    </button>
  );
};

export const AnimatedCheckmark: React.FC<{ className?: string }> = ({ className = '' }) => {
  const [isHovered, setIsHovered] = useState(false);

  return (
    <div
      className={`relative ${className}`}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      <div className={`
        h-5 w-5 rounded-full bg-green-500 flex items-center justify-center
        transition-all duration-300 transform
        ${isHovered ? 'scale-110 shadow-lg shadow-green-500/50 animate-pulse' : ''}
      `}>
        <svg
          className={`h-3 w-3 text-white transition-all duration-300 ${isHovered ? 'animate-bounce' : ''}`}
          fill="none"
          stroke="currentColor"
          viewBox="0 0 24 24"
        >
          <path
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeWidth={3}
            d="M5 13l4 4L19 7"
          />
        </svg>
      </div>
      {isHovered && (
        <div className="absolute inset-0 rounded-full bg-green-400 animate-ping opacity-20" />
      )}
    </div>
  );
};
