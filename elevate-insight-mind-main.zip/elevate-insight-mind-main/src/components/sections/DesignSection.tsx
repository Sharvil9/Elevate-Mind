
import React from 'react';

export const DesignSection = () => {
  return (
    <section className="section-spacing bg-meditation-gradient">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-16">
          <div className="inline-flex items-center bg-white/20 backdrop-blur-sm rounded-full px-8 py-4">
            <h2 className="font-cormorant text-4xl md:text-5xl font-medium text-white">
              Typography & Colors
            </h2>
          </div>
        </div>

        {/* Typography Showcase */}
        <div className="text-center">
          {/* Main Font */}
          <div className="mb-12">
            <p className="text-white/80 text-left mb-4">Main font</p>
            <h3 className="font-cormorant text-6xl md:text-8xl text-white font-light relative">
              Cormorant Infant
              <span className="absolute -top-2 -right-2 bg-white/20 backdrop-blur-sm rounded-lg px-3 py-1 text-sm">
                34px
              </span>
              <span className="absolute -bottom-2 right-20 bg-white/20 backdrop-blur-sm rounded-lg px-3 py-1 text-sm">
                24px
              </span>
            </h3>
          </div>

          {/* Secondary Font */}
          <div className="mb-12">
            <p className="text-white/80 text-left mb-4">Second font</p>
            <h3 className="font-inter text-4xl md:text-6xl text-white font-light relative">
              Inter
              <span className="absolute -top-2 -right-2 bg-white/20 backdrop-blur-sm rounded-lg px-3 py-1 text-sm">
                16px
              </span>
              <span className="absolute -bottom-2 right-16 bg-white/20 backdrop-blur-sm rounded-lg px-3 py-1 text-sm">
                18px
              </span>
              <span className="absolute bottom-8 left-0 bg-white/20 backdrop-blur-sm rounded-lg px-3 py-1 text-sm">
                12px
              </span>
            </h3>
          </div>

          {/* Color Palette */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mt-16">
            <div className="text-center">
              <div className="w-20 h-20 bg-meditation-teal rounded-full mx-auto mb-3 shadow-lg"></div>
              <p className="text-white/80 text-sm">Primary Teal</p>
              <p className="text-white/60 text-xs">#4A9B9B</p>
            </div>
            <div className="text-center">
              <div className="w-20 h-20 bg-meditation-teal-light rounded-full mx-auto mb-3 shadow-lg"></div>
              <p className="text-white/80 text-sm">Light Teal</p>
              <p className="text-white/60 text-xs">#5DABAD</p>
            </div>
            <div className="text-center">
              <div className="w-20 h-20 bg-white rounded-full mx-auto mb-3 shadow-lg"></div>
              <p className="text-white/80 text-sm">Pure White</p>
              <p className="text-white/60 text-xs">#FFFFFF</p>
            </div>
            <div className="text-center">
              <div className="w-20 h-20 bg-gray-800 rounded-full mx-auto mb-3 shadow-lg"></div>
              <p className="text-white/80 text-sm">Dark Gray</p>
              <p className="text-white/60 text-xs">#2A2A2A</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
