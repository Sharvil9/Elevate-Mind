
import React from 'react';
import { Brain, Heart, Shield, TrendingUp, Users, Sparkles } from 'lucide-react';

export const FeaturesSection = () => {
  return (
    <section className="section-spacing bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-16">
          <div className="inline-flex items-center gap-4 bg-meditation-teal/10 rounded-full px-8 py-4">
            <span className="w-10 h-10 bg-meditation-teal rounded-full flex items-center justify-center text-white text-lg font-bold flex-shrink-0">1</span>
            <h2 className="font-cormorant text-4xl md:text-5xl font-medium text-meditation-primary">
              Problem & Solutions
            </h2>
          </div>
        </div>

        {/* Problem & Solutions Grid */}
        <div className="grid lg:grid-cols-2 gap-12 items-start">
          {/* Problem Card */}
          <div className="bg-meditation-gradient rounded-3xl p-8 text-white">
            <h3 className="font-cormorant text-3xl font-medium mb-6">Problem</h3>
            <p className="text-white/90 mb-8 leading-relaxed">
              Modern life is often accompanied by chronic stress, anxiety, and emotional burnout. 
              Many people don't have the time or knowledge to maintain mental health. Existing apps 
              are often overloaded with features or don't provide an easy way to relax and focus on yourself.
            </p>
            
            <div className="bg-white/20 rounded-2xl p-6 backdrop-blur-sm">
              <h4 className="text-2xl font-cormorant font-medium mb-3">
                67% of people feel overwhelmed by their daily digital tools
              </h4>
            </div>
            <div className="bg-white/20 rounded-2xl p-6 backdrop-blur-sm mt-4">
              <h4 className="text-2xl font-cormorant font-medium mb-3">
                Anxiety disorders affect 284 million people globally
              </h4>
              <p className="text-white/80 text-sm">Source: Our World in Data (2018)</p>
            </div>
          </div>

          {/* Solutions Card */}
          <div className="bg-white border-2 border-meditation-teal/20 rounded-3xl p-8">
            <h3 className="font-cormorant text-3xl font-medium text-gray-900 mb-6">Solutions</h3>
            <p className="text-gray-700 mb-8 leading-relaxed">
              I created an intuitive and visually calm application that:
            </p>
            
            <div className="space-y-4">
              {[
                "Helps users to quickly find meditations for their state (stress, anxiety, insomnia);",
                "Has simple navigation and a minimalist design that does not distract;",
                "Allows you to create your own meditation collections and track your mood;",
                "Gives you the experience of taking care of yourself at any time - at home, in transportation, or before bed."
              ].map((solution, index) => (
                <div key={index} className="flex items-start gap-3">
                  <div className="w-6 h-1 bg-gray-900 rounded-full mt-3"></div>
                  <p className="text-gray-700">{solution}</p>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Testimonial - Shortened */}
        <div className="mt-16 text-center">
          <div className="max-w-4xl mx-auto">
            <div className="text-6xl text-meditation-teal/20 mb-4">"</div>
            <blockquote className="text-xl md:text-2xl text-gray-700 font-light leading-relaxed mb-6">
              <span className="text-meditation-primary">Unlike other meditation apps with overwhelming features,</span>
              {" "}this app felt calm from the first moment. 
              <span className="text-meditation-primary"> Everything is intuitive and distraction-free.</span>
              {" "}I chose Stress Relief meditation and <span className="text-meditation-primary">finally managed to relax.</span>
            </blockquote>
          </div>
        </div>
      </div>
    </section>
  );
};
