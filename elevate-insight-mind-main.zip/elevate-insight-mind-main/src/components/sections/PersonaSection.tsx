import React from 'react';
import { MapPin, Briefcase, Heart, Target, Clock, Smartphone, Book, Coffee } from 'lucide-react';

export const PersonaSection = () => {
  return (
    <section className="section-spacing bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-16">
          <div className="inline-flex items-center gap-4 bg-meditation-teal/10 rounded-full px-8 py-4">
            <span className="w-10 h-10 bg-meditation-teal rounded-full flex items-center justify-center text-white text-lg font-bold flex-shrink-0">3</span>
            <h2 className="font-cormorant text-4xl md:text-5xl font-medium text-meditation-primary">
              User Persona
            </h2>
          </div>
        </div>

        {/* Enhanced Persona Layout */}
        <div className="grid lg:grid-cols-3 gap-8 items-start mb-12">
          {/* User Info Card */}
          <div className="persona-card bg-meditation-gradient text-white">
            <div className="flex items-center gap-4 mb-6">
              <div className="w-16 h-16 bg-orange-400 rounded-full flex items-center justify-center text-3xl">
                👩
              </div>
              <div>
                <h3 className="font-cormorant text-2xl font-medium">Anna Melnyk</h3>
                <p className="text-white/80 text-sm">Tech Professional</p>
              </div>
            </div>
            
            <div className="space-y-4 text-white/90">
              <div className="flex items-center gap-3">
                <Clock className="h-4 w-4 flex-shrink-0" />
                <div>
                  <span className="font-medium">Age:</span>
                  <span className="ml-2">28 years old</span>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <Briefcase className="h-4 w-4 mt-1 flex-shrink-0" />
                <div>
                  <span className="font-medium">Occupation:</span>
                  <span className="ml-2">Junior Project Manager in IT</span>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <MapPin className="h-4 w-4 flex-shrink-0" />
                <div>
                  <span className="font-medium">Location:</span>
                  <span className="ml-2">Lviv, Ukraine</span>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <Heart className="h-4 w-4 flex-shrink-0" />
                <div>
                  <span className="font-medium">Status:</span>
                  <span className="ml-2">Single</span>
                </div>
              </div>
            </div>

            {/* Personality Traits */}
            <div className="mt-6 pt-6 border-t border-white/20">
              <h4 className="font-medium mb-3">Personality Traits</h4>
              <div className="flex flex-wrap gap-2">
                <span className="bg-white/20 px-3 py-1 rounded-full text-sm">Ambitious</span>
                <span className="bg-white/20 px-3 py-1 rounded-full text-sm">Analytical</span>
                <span className="bg-white/20 px-3 py-1 rounded-full text-sm">Stressed</span>
              </div>
            </div>
          </div>

          {/* User Photo */}
          <div className="flex justify-center">
            <div className="persona-card">
              <img 
                src="https://images.unsplash.com/photo-1649972904349-6e44c42644a7?w=400&h=400&fit=crop&crop=face"
                alt="Anna Melnyk - Professional woman using laptop"
                className="w-full h-80 object-cover rounded-2xl"
              />
              <div className="mt-4 text-center">
                <p className="text-gray-600 text-sm italic">
                  "I need quick, effective ways to manage stress during my busy workday"
                </p>
              </div>
            </div>
          </div>

          {/* About & Tech Profile Card */}
          <div className="persona-card">
            <div className="flex items-center gap-3 mb-6">
              <div className="w-8 h-8 bg-pink-400 rounded-full flex items-center justify-center">
                🧠
              </div>
              <h3 className="font-cormorant text-2xl font-medium text-gray-900">About Anna</h3>
            </div>
            
            <p className="text-gray-700 leading-relaxed mb-6">
              Anna works in a fast-paced IT environment with constant deadlines and context switching. 
              She struggles with work-life balance and often feels anxious after long days. 
              She's tech-savvy but prefers simple, intuitive apps.
            </p>

            {/* Tech & Habits */}
            <div className="space-y-3">
              <div className="flex items-center gap-3 text-gray-600">
                <Smartphone className="h-4 w-4" />
                <span className="text-sm">iPhone user, values privacy</span>
              </div>
              <div className="flex items-center gap-3 text-gray-600">
                <Book className="h-4 w-4" />
                <span className="text-sm">Reads self-help blogs</span>
              </div>
              <div className="flex items-center gap-3 text-gray-600">
                <Coffee className="h-4 w-4" />
                <span className="text-sm">Drinks 3+ coffees daily</span>
              </div>
            </div>
          </div>
        </div>

        {/* Enhanced Goals & Pain Points Section */}
        <div className="grid md:grid-cols-2 gap-8">
          {/* Goals */}
          <div className="persona-card bg-meditation-gradient text-white">
            <div className="flex items-center gap-3 mb-6">
              <Target className="h-8 w-8 text-green-400" />
              <h3 className="font-cormorant text-2xl font-medium">Goals & Motivations</h3>
            </div>
            
            <div className="space-y-4">
              {[
                "Reduce anxiety and stress after work",
                "Learn to focus better during busy periods", 
                "Build a consistent self-care routine",
                "Find quick meditations for on-the-go relief",
                "Improve sleep quality and evening routine"
              ].map((goal, index) => (
                <div key={index} className="flex items-start gap-3">
                  <div className="w-6 h-1 bg-green-400 rounded-full mt-3 flex-shrink-0"></div>
                  <p className="text-white/90">{goal}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Pain Points & Frustrations */}
          <div className="persona-card border-2 border-red-100">
            <div className="flex items-center gap-3 mb-6">
              <div className="w-8 h-8 bg-red-400 rounded-full flex items-center justify-center text-white">
                ⚠️
              </div>
              <h3 className="font-cormorant text-2xl font-medium text-gray-900">Pain Points</h3>
            </div>
            
            <div className="space-y-4">
              {[
                "No time for long meditation sessions",
                "Overwhelmed by complex app interfaces",
                "Difficulty falling asleep due to racing thoughts",
                "Lack of motivation to stick to wellness routines",
                "Skeptical about meditation effectiveness"
              ].map((pain, index) => (
                <div key={index} className="flex items-start gap-3">
                  <div className="w-6 h-1 bg-red-400 rounded-full mt-3 flex-shrink-0"></div>
                  <p className="text-gray-700">{pain}</p>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* User Journey Timeline */}
        <div className="mt-12 persona-card">
          <h3 className="font-cormorant text-2xl font-medium text-gray-900 mb-6 text-center">
            Anna's Daily Journey
          </h3>
          <div className="flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0">
            {[
              { time: "7:00 AM", activity: "Stressful commute", mood: "😰" },
              { time: "12:00 PM", activity: "Lunch break relief", mood: "😌" },
              { time: "6:00 PM", activity: "Work deadline pressure", mood: "😤" },
              { time: "10:00 PM", activity: "Struggles to unwind", mood: "😟" }
            ].map((item, index) => (
              <div key={index} className="text-center">
                <div className="w-12 h-12 bg-meditation-teal/10 rounded-full flex items-center justify-center text-2xl mb-2 mx-auto">
                  {item.mood}
                </div>
                <p className="font-medium text-gray-900">{item.time}</p>
                <p className="text-sm text-gray-600">{item.activity}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};
