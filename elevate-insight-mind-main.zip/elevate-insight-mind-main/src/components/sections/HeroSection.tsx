
import React from 'react';
import { Button } from '@/components/ui/button';
import { useNavigate } from 'react-router-dom';
import { ArrowRight, Sparkles } from 'lucide-react';
import { InteractivePhone } from '@/components/ui/interactive-phone';

export const HeroSection = () => {
  const navigate = useNavigate();

  return (
    <section className="relative min-h-screen flex items-center justify-center bg-calm-gradient overflow-hidden pb-32">
      {/* Background Elements */}
      <div className="absolute inset-0 bg-nature-gradient opacity-20"></div>
      
      {/* Extended Teal Background for Phone */}
      <div className="absolute bottom-0 left-0 right-0 h-80 bg-meditation-gradient opacity-30"></div>
      
      {/* Floating Elements */}
      <div className="absolute top-20 left-10 w-20 h-20 bg-meditation-teal/10 rounded-full animate-float-gentle"></div>
      <div className="absolute top-40 right-16 w-16 h-16 bg-meditation-teal-light/15 rounded-full animate-float-gentle" style={{animationDelay: '-2s'}}></div>
      <div className="absolute bottom-32 left-20 w-12 h-12 bg-meditation-teal/20 rounded-full animate-float-gentle" style={{animationDelay: '-1s'}}></div>

      <div className="relative z-10 max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        {/* Badge */}
        <div className="inline-flex items-center gap-2 bg-white/80 backdrop-blur-sm border border-meditation-teal/20 rounded-full px-6 py-3 mb-8 animate-fade-up">
          <Sparkles className="h-4 w-4 text-meditation-primary" />
          <span className="text-sm font-medium text-meditation-primary">Mental Health & Meditation</span>
        </div>

        {/* Main Heading */}
        <h1 className="font-cormorant text-5xl md:text-7xl lg:text-8xl font-light text-gray-900 mb-6 animate-fade-up">
          Mental health
          <br />
          <span className="text-meditation-primary font-medium">and meditation</span>
        </h1>

        {/* Subtitle */}
        <p className="text-lg md:text-xl text-gray-600 max-w-3xl mx-auto mb-12 leading-relaxed animate-fade-in-delay">
          A concept of a mindfulness app that allows users to choose themed 
          meditations, follow short courses, and track their progress. 
          The main goal is to design a calm and intuitive interface.
        </p>

        {/* CTA Buttons */}
        <div className="flex flex-col sm:flex-row gap-4 justify-center animate-fade-in-delay">
          <button 
            onClick={() => navigate('/dashboard')}
            className="meditation-button flex items-center justify-center gap-3 text-lg"
          >
            Start Your Journey
            <ArrowRight className="h-5 w-5" />
          </button>
          
          <Button 
            variant="outline" 
            size="lg" 
            className="px-8 py-4 text-lg border-2 border-meditation-teal text-meditation-primary hover:bg-meditation-teal hover:text-white transition-all duration-300"
          >
            Learn More
          </Button>
        </div>

        {/* Interactive App Preview */}
        <div className="mt-20 animate-fade-in-delay">
          <InteractivePhone />
        </div>
      </div>
    </section>
  );
};
